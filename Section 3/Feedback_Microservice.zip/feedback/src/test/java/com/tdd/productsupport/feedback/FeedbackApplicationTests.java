package com.tdd.productsupport.feedback;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackApplicationTests {

    @BeforeEach
    public void setup(){

    }

}
